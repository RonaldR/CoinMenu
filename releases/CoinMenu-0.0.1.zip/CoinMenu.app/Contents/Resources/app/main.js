
var menubar = require('menubar');

var mb = menubar({
  preloadWindow: true,
  width: 360,
  height: 320,
});

mb.on('ready', function ready () {

  // mb.window.openDevTools();

});
