## CoinMenu

Menubar app to keep track of your Cryptocoins.
Build in Electron based on: https://github.com/maxogden/menubar/


## instructions

- run `npm install`
- run `npm run build` to make Example.app
- run `npm start` to run app from CLI without building Example.app


### API used: https://coinmarketcap.com/api/

Created by Ronald Runia  
Idea and collaboration by Martijn de Haan
